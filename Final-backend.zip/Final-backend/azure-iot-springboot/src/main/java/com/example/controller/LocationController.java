package com.example.controller;

import com.example.dto.LocationRequest;
import com.example.entity.Location;

import com.example.service.LocationService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import java.util.Optional;

@RestController
@CrossOrigin("*")

@RequestMapping("/locations")

public class LocationController {

  private final LocationService locationService;

  public LocationController(LocationService locationService) {

    this.locationService = locationService;

  }


  @PostMapping("/add")
  @PreAuthorize("hasAuthority('ADMIN')")


  public ResponseEntity<LocationRequest> createLocation(@RequestBody LocationRequest locationDTO) {

    LocationRequest savedLocation = locationService.createLocation(locationDTO);

    return ResponseEntity.ok(savedLocation);

  }


  @GetMapping

  public ResponseEntity<List<LocationRequest>> getAllLocations() {

    return ResponseEntity.ok(locationService.getAllLocations());

  }


  @GetMapping("/{id}")

  public ResponseEntity<LocationRequest> getLocationById(@PathVariable int id) {

    return ResponseEntity.ok(locationService.getLocationById(id));

  }


  @PutMapping("/{id}")
  @PreAuthorize("hasAuthority('ADMIN')")


  public ResponseEntity<LocationRequest> updateLocation(@PathVariable int id,
      @RequestBody LocationRequest locationDTO) {

    return ResponseEntity.ok(locationService.updateLocation(id, locationDTO));

  }


  @DeleteMapping("/{id}")

  public ResponseEntity<String> deleteLocation(@PathVariable int id) {

    locationService.deleteLocation(id);

    return ResponseEntity.ok("Location deleted successfully!");

  }

}
