package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.repository.LocationRepository;
import com.example.dto.AtmRequest;
import com.example.dto.BranchRequest;
import com.example.dto.LocationRequest;
import com.example.entity.Atm;
import com.example.entity.Branch;
import com.example.entity.Location;
import com.example.repository.AtmRepository;
import com.example.repository.BranchRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final LocationRepository locationRepository;
    private final BranchRepository branchRepository;
    private final AtmRepository atmRepository;

    public String addLocation(LocationRequest request) {

        Location location = new Location();

        location.setName(request.getName());

        locationRepository.save(location);

        return "Location added successfully";

    }

    public String addBranch(BranchRequest request) {

        Location location = locationRepository.findById(request.getLocationId())

                .orElseThrow(() -> new RuntimeException("Location not found"));

        Branch branch = new Branch();

        branch.setBranchName(request.getBranchName());

        branch.setLocation(location);

        branchRepository.save(branch);

        return "Branch added successfully";

    }

    public String addAtm(AtmRequest request) {

        Branch branch = branchRepository.findById(request.getAtmId())

                .orElseThrow(() -> new RuntimeException("Branch not found"));

        Atm atm = new Atm();

        atm.setAtmCode(request.getAtmCode());

        atm.setStatus(request.getStatus());

        atm.setBranch(branch);

        atmRepository.save(atm);

        return "ATM added successfully";

    }

}