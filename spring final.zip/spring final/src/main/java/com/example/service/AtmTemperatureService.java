package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.entity.AtmTemperature;
import com.example.repository.AtmTemperatureRepository;

public class AtmTemperatureService {
        @Autowired
    private AtmTemperatureRepository atmTemperatureRepository;

    public AtmTemperature saveAtmTemperature(AtmTemperature atmTemperature) {
        return atmTemperatureRepository.save(atmTemperature);
    }

    public List<AtmTemperature> getAllAtmTemperatures() {
        return atmTemperatureRepository.findAll();
    }
}
