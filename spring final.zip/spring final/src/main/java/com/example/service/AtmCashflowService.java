package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.entity.AtmCashflow;
import com.example.repository.AtmCashflowRepository;

public class AtmCashflowService {
     @Autowired
    private AtmCashflowRepository atmCashflowRepository;
    
    public AtmCashflow saveAtmCashflow(AtmCashflow atmCashflow) {
        return atmCashflowRepository.save(atmCashflow);
    }

    public List<AtmCashflow> getAllAtmCashflows() {
        return atmCashflowRepository.findAll();
    }
    
}
