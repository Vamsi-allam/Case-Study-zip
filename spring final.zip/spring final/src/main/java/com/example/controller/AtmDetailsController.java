package com.example.controller;

import com.example.dto.AtmDetailsRequest;
import com.example.dto.AtmRequest;
import com.example.service.AtmDetailsService;
import com.example.service.AtmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/atm-details")
@CrossOrigin("*")
public class AtmDetailsController {
    @Autowired
    private AtmDetailsService atmDetailsService;
    @Autowired
    private AtmService atmService;
    @GetMapping("/{atmId}")
    public AtmDetailsRequest getAtmDetails(@PathVariable int atmId) {
        return atmDetailsService.getAtmDetails(atmId);
    }
    @GetMapping("/atms")
    public ResponseEntity<List<AtmRequest>> getAllATMs() {
        return ResponseEntity.ok(atmService.getAllATMs());
    }
    @GetMapping("/atms/{id}")
    public ResponseEntity<AtmRequest> getATMById(@PathVariable int id) {
        return ResponseEntity.ok(atmService.getATMById(id));
    }
    @GetMapping("/branches/{branchId}/atms")
    public ResponseEntity<List<AtmRequest>> getATMsByBranch(@PathVariable int branchId) {
        return ResponseEntity.ok(atmService.getATMsByBranchId(branchId));
    }
    @PostMapping("/branches/{branchId}/atms")
    public ResponseEntity<AtmRequest> addATM(@PathVariable int branchId, @RequestBody AtmRequest atmDTO) {
        return ResponseEntity.ok(atmService.saveATM(atmDTO, branchId));
    }
    @PutMapping("/atms/{id}")
    public ResponseEntity<AtmRequest> updateATM(@PathVariable int id, @RequestBody AtmRequest atmDTO) {
        return ResponseEntity.ok(atmService.updateATM(id, atmDTO));
    }
    @DeleteMapping("/atms/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteATM(@PathVariable int id) {
        atmService.deleteATM(id);
        return ResponseEntity.noContent().build();
    }
}