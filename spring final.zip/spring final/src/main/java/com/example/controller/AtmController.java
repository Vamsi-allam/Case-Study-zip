package com.example.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.AtmCashflow;
import com.example.entity.AtmTemperature;
import com.microsoft.azure.sdk.iot.device.DeviceClient;
import com.microsoft.azure.sdk.iot.device.IotHubClientProtocol;
import com.microsoft.azure.sdk.iot.device.IotHubStatusCode;
import com.microsoft.azure.sdk.iot.device.Message;
import com.microsoft.azure.sdk.iot.device.MessageSentCallback;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class AtmController {

   

    private String connStringtemp = "HostName=iothub-team4.azure-devices.net;DeviceId=tempdev1;SharedAccessKey=wMy9kAtZHFexJCbjc81X8g0zQv8IVL5RrXjcS2ltD98=";
    private String connStringcash = "HostName=iothub-team4.azure-devices.net;DeviceId=cashdev1;SharedAccessKey=by80HKP78b4JdSIx+Bk0wSComInHGKHfL0P7eD88w5M=";
    

    // private String connStringtemp =
    // "HostName=atm.azure-devices.net;DeviceId=ATMTempDevice;SharedAccessKey=HmeAtNI9+WsFa8FCm3IRsUr4iDT9Vj4/eyH1ytw+ec0=";
    // private String connStringcash =
    // "HostName=atm.azure-devices.net;DeviceId=ATMCashDevice;SharedAccessKey=TM9UEAIEfeGCj7r+VdUW+XNtoeFSgYZHIF1K1+EiLKc=";
    private static IotHubClientProtocol protocol = IotHubClientProtocol.MQTT;

    private static class EventCallback implements MessageSentCallback {
        private String status;

        @Override
        public void onMessageSent(Message sentMessage, IotHubClientException exception, Object callbackContext) {
            status = (exception == null ? IotHubStatusCode.OK.toString() : exception.getStatusCode().toString());
            System.out.println("IoT Hub responded to message with status: " + status);
            if (callbackContext != null) {
                synchronized (callbackContext) {
                    callbackContext.notify();
                }
            }
        }

        public String getStatus() {
            return status;
        }
    }

    @PostMapping("/sendtemp")
    public ResponseEntity<?> createAtmTemperature(@RequestBody AtmTemperature atmTemperature) {
        try {
            // if (atmTemperature.getTimestamp() == null) {
            // atmTemperature.setTimestamp(LocalDateTime.now().toString());
            // }

            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringtemp, protocol);
                client.open(true);

                String msgStr = atmTemperature.serialize();
                Message msg = new Message(msgStr);
                msg.setProperty("type", String.valueOf(atmTemperature.getType()));
                // msg.setProperty("temperatureAlert", (telemetryData.getTemperature() > 40) ?
                // "true" : "false");

                System.out.println("Sending message: " + msgStr);

                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }

                // Send telemetry data to Azure Service Bus and store in SQL database
                // sendDataToServiceBus.sendTelemetryData(telemetryData);
                // sendDataToServiceBus.receiveTelemetryData();
                return ResponseEntity.ok("Message sent successfully to IoT Hub with status: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (IotHubClientException e) {
            return ResponseEntity.status(500).body("IoT Hub client error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body("Invalid telemetry data: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error sending message to IoT Hub: " + e.getMessage());
        }
    }

    @PostMapping("/sendcash")
    public ResponseEntity<?> createAtmCashflow(@RequestBody AtmCashflow atmCashflow) {
        try {

            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringcash, protocol);
                client.open(true);

                String msgStr = atmCashflow.serialize();
                Message msg = new Message(msgStr);
                msg.setProperty("type", String.valueOf(atmCashflow.getType()));
                // msg.setProperty("temperatureAlert", (telemetryData.getTemperature() > 40) ?
                // "true" : "false");

                System.out.println("Sending message: " + msgStr);

                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }

                // Send telemetry data to Azure Service Bus and store in SQL database
                // sendDataToServiceBus.sendTelemetryData(telemetryData);
                // sendDataToServiceBus.receiveTelemetryData();
                return ResponseEntity.ok("Message sent successfully to IoT Hub with status: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (IotHubClientException e) {
            return ResponseEntity.status(500).body("IoT Hub client error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(400).body("Invalid telemetry data: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error sending message to IoT Hub: " + e.getMessage());
        }
    }

   
}