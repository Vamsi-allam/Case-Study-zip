package com.example.config;

import lombok.RequiredArgsConstructor;

import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;

import org.springframework.security.authentication.ProviderManager;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.core.userdetails.UserDetailsService;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.entity.Role;
import com.example.service.JwtService;



@Configuration

@RequiredArgsConstructor

public class SecurityConfig {



  private final JwtAuthenticationFilter jwtAuthenticationFilter;



  @Bean

  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

    http.csrf().disable()

        .authorizeHttpRequests(auth -> auth

            .requestMatchers("/auth/**").permitAll()
            .requestMatchers("/branches/**").permitAll()
            .requestMatchers("/locations/**").permitAll()
            .requestMatchers("/locations/**").authenticated()
            .requestMatchers("/locations/add").hasAuthority(Role.ADMIN.name())
            .requestMatchers("/locations/{id}").hasAuthority(Role.ADMIN.name())

            .requestMatchers("/admin/**").hasAuthority(Role.ADMIN.name())
            .requestMatchers("/api/atms/**").authenticated()

            .requestMatchers("/technician/**").hasAuthority(Role.TECHNICIAN.name())

            .anyRequest().authenticated()

        ).addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);



    return http.build();

  }



  @Bean

  public PasswordEncoder passwordEncoder() {

    return new BCryptPasswordEncoder();

  }



  @Bean

  public AuthenticationManager authenticationManager(UserDetailsService userDetailsService) {

    DaoAuthenticationProvider provider = new DaoAuthenticationProvider();

    provider.setUserDetailsService(userDetailsService);

    provider.setPasswordEncoder(passwordEncoder());

    return new ProviderManager(provider);

  }

}