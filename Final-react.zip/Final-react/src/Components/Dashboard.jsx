import React, { useState, useEffect } from "react";
import {
  FaBuilding,
  FaCheckCircle,
  FaTimesCircle,
  FaArrowRight,
  FaMoon,
  FaSun,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import "@fontsource/roboto";
import "../Components/Dashboard.css"; // Keep the custom CSS file

const Dashboard = ({ darkMode, toggleDarkMode }) => {
  const [atms, setAtms] = useState([]);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetch("http://127.0.0.1:2003/atm-details/atms", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => {
        if (!response.ok) throw new Error("Failed to fetch ATMs");
        return response.json();
      })
      .then((data) => setAtms(data))
      .catch((error) => console.error("Error fetching ATMs:", error));
  }, [token]);

  // Count active & inactive ATMs
  const totalATMs = atms.length;
  const activeATMs = atms.filter((atm) => atm.status === "Active").length;
  const inactiveATMs = totalATMs - activeATMs;

  return (
    <div className={`dashboard-container ${darkMode ? "dark-mode" : "light-mode"}`}>
      {/* Navbar with Dark Mode Toggle */}
      <nav className="navbar">
        <button className="toggle-mode" onClick={toggleDarkMode}>
          {darkMode ? <FaSun size={20} /> : <FaMoon size={20} />}
        </button>
      </nav>

      {/* Main Content */}
      <div className="content">
        {/* Stats Boxes */}
        <div className="stats-container">
          {[
            { title: "Total ATMs", icon: <FaBuilding />, value: totalATMs },
            { title: "Active ATMs", icon: <FaCheckCircle />, value: activeATMs },
            { title: "Inactive ATMs", icon: <FaTimesCircle />, value: inactiveATMs },
          ].map((item, index) => (
            <div key={index} className="stats-box">
              <div className="stats-icon">{item.icon}</div>
              <h6 className="stats-title">{item.title}</h6>
              <p className="stats-value">{item.value}</p>
            </div>
          ))}
        </div>

        {/* ATM List */}
        <div className="atm-container">
          <h3 className="atm-header">ATM Details</h3>
          <div className="atm-list">
            {atms.map((atm) => (
              <Link key={atm.atmId} to={`/atm/${atm.atmId}`} className="atm-item">
                <span
                  className={`atm-id ${
                    atm.status === "Active"
                      ? "dashboard-active-atm"
                      : "dashboard-inactive-atm"
                  }`}
                >
                  {atm.atmCode}
                </span>
                <span className="atm-details">
                  Show Details <FaArrowRight />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
