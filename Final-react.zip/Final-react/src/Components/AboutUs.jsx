import React from 'react';
import { useNavigate } from 'react-router-dom';
import './aboutus.css'; // Add styles for the About Us page
 
const AboutUs = () => {
  const navigate = useNavigate();
 
  const teamMembers = [
    { name: 'Vamsi Allam', email: 'vamsi.allam@outlook.com' },
    { name: 'Vignesh Nandakumar', email: 'vignesh.nandakumar@outlook.com' },
    { name: 'Rahul Mishra', email: 'Rahul.Mishra4@outlook.com' },
    { name: 'Yamuna Pottepaka', email: 'yamuna.pottepaka@outlook.com' },
    { name: 'Vamshidhar Jogula', email: 'jogula.vamshidhar@outlook.com' },
  ];
 
  return (
    <div className="aboutus-container">
      {/* Navigation Bar */}
      <nav className="home-navbar">
        <div className="home-logo">ATM-MONITORING</div>
        <div className="home-nav-links">
          <a onClick={() => navigate('/')} className="nav-link active">Home</a>
          <a onClick={() => navigate('/about')} className="nav-link active">About Us</a>
          <a onClick={() => navigate('/login')} className="nav-link active">Login</a>
        </div>
      </nav>
 
      {/* About Us Content */}
      <div className="aboutus-content">
        <h1 className="aboutus-heading">Meet Our Team</h1>
        <p className="aboutus-intro">
          We are a team of dedicated professionals committed to delivering the best ATM monitoring solutions.
          Our expertise spans across various domains to ensure seamless operations and customer satisfaction.
        </p>
        <div className="aboutus-cards">
          {teamMembers.map((member, index) => (
            <div key={index} className="aboutus-card">
              <h2 className="card-name">{member.name}</h2>
              <p className="card-email">{member.email}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
 
export default AboutUs;
 